Validation script for hw2-3

To run:

npm install
node validate.js

To see extra options (if you are running the blog or mongodb on different hosts or ports):

node validate.js --help
